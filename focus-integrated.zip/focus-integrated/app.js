// ================================================================
// Focus Integrated - app.js
// focus-tool (Pomodoro + low-poly mask + attention) merged with
// emotion-test (5 Ollama AI functions)
// ================================================================

// ── DOM ──
const videoElement      = document.getElementById("video");
const canvasElement     = document.getElementById("canvas");
const canvasCtx         = canvasElement.getContext("2d");
const statusBox         = document.getElementById("statusBox");
const toastContainer    = document.getElementById("toastContainer");

const timerEl           = document.getElementById("timer");
const statusTextEl      = document.getElementById("statusText");
const idleTextEl        = document.getElementById("idleText");
const startPauseBtn     = document.getElementById("startPauseBtn");
const resetBtn          = document.getElementById("resetBtn");
const workBtn           = document.getElementById("workBtn");
const breakBtn          = document.getElementById("breakBtn");
const workMinutesInput  = document.getElementById("workMinutesInput");
const breakMinutesInput = document.getElementById("breakMinutesInput");

const mentalStateBox    = document.getElementById("mentalStateBox");
const mentalIcon        = document.getElementById("mentalIcon");
const mentalLabel       = document.getElementById("mentalLabel");

const adviceBox         = document.getElementById("adviceBox");
const predictionBox     = document.getElementById("predictionBox");
const aiRawResponseBox  = document.getElementById("aiRawResponseBox");
const analyticsBox      = document.getElementById("analyticsBox");
const aiLogBox          = document.getElementById("aiLogBox");

const ollamaUrlInput    = document.getElementById("ollamaUrlInput");
const ollamaModelInput  = document.getElementById("ollamaModelInput");

// ================================================================
// OLLAMA CONFIG
// ================================================================
function getOllamaConfig() {
  return {
    baseUrl: ollamaUrlInput.value.trim() || "http://127.0.0.1:11434",
    model:   ollamaModelInput.value.trim() || "gemma3:4b"
  };
}

// ================================================================
// SHARED STUDENT STATE
// ================================================================
let studentState = { emotion: "neutral", attention: "focused", mentalStatus: "focused" };

// AI history (persisted to localStorage, same as emotion-test)
let stateHistory    = JSON.parse(localStorage.getItem("stateHistory"))    || [];
let adaptiveParams  = JSON.parse(localStorage.getItem("adaptiveParams"))  || {
  distractedThreshold:  40,
  reminderInterval:     30000,
  reminderType:         "text",
  blinkRateNormalRange: [2, 8]
};
let lastAICallState = { emotion: "", attention: "" };
let lastState       = { emotion: "", attention: "" };
let stateStableTimer = null;

// ================================================================
// ATTENTION DETECTION VARIABLES
// ================================================================
let distractedFrames = 0;
let blinkTimes       = [];
let lastBlinkTime    = 0;
let lastGaze         = 0;

// ================================================================
// POMODORO TIMER STATE
// ================================================================
const DEFAULT_WORK_SECONDS  = 25 * 60;
const DEFAULT_BREAK_SECONDS = 5 * 60;

let workSeconds      = DEFAULT_WORK_SECONDS;
let breakSeconds     = DEFAULT_BREAK_SECONDS;
let mode             = "work";
let remainingSeconds = workSeconds;
let isRunning        = false;
let endTimestamp     = null;

// ================================================================
// IDLE DETECTION
// ================================================================
let lastActivity    = Date.now();
let hasIdleNotified = false;

// ================================================================
// FOCUS REMINDER STATE
// ================================================================
let lastReminderTime = 0;
const REMINDER_COOLDOWN_MS = 10000;

const encourageMessages = [
  "💪 You can do it! Stay focused!",
  "🌟 Keep going, you're doing great!",
  "🎯 Stay on track, one step at a time!",
  "🔥 You're almost there, keep pushing!",
  "📚 Take a deep breath and refocus!",
  "🧠 Clear your mind and continue!",
  "✨ Every minute of focus counts!",
  "🏆 Champions stay focused, and so will you!"
];

const warningMessages = {
  lost_focus:  "⚠️ Your attention seems to be drifting! Look at the screen.",
  struggling:  "😟 You seem frustrated. Take a deep breath and try again.",
  fatigued:    "😴 Feeling tired? Maybe take a short break soon.",
  anxious:     "😰 You seem anxious. Relax, you've got this!",
  frustrated:  "😤 Feeling stuck? Step back and think about it differently."
};

// ================================================================
// TOAST SYSTEM
// ================================================================
function showToast(text, type = "info", duration = 4000) {
  const toast = document.createElement("div");
  toast.classList.add("toast", type);
  toast.textContent = text;
  toastContainer.appendChild(toast);
  setTimeout(() => toast.remove(), duration);
}

// ================================================================
// FOCUS REMINDER LOGIC
// ================================================================
function checkAndRemind() {
  const now = Date.now();
  if (now - lastReminderTime < REMINDER_COOLDOWN_MS) return;
  if (mode !== "work" || !isRunning) return;

  const { mentalStatus, attention } = studentState;
  if (attention === "distracted" || warningMessages[mentalStatus]) {
    lastReminderTime = now;
    const warningText = warningMessages[mentalStatus] || warningMessages.lost_focus;
    showToast(warningText, "warning", 5000);
    setTimeout(() => {
      const msg = encourageMessages[Math.floor(Math.random() * encourageMessages.length)];
      showToast(msg, "encourage", 4000);
    }, 2000);
    playBeep();
  }
}

// ================================================================
// MENTAL STATE DISPLAY
// ================================================================
const mentalIcons = {
  focused: "😊", engaged: "🤩", lost_focus: "😵",
  struggling: "😣", fatigued: "😴", anxious: "😰", frustrated: "😤"
};

function updateMentalStateUI() {
  const status = studentState.mentalStatus;
  mentalStateBox.className = "mental-state " + status;
  mentalIcon.textContent   = mentalIcons[status] || "😊";
  mentalLabel.textContent  = status.replace("_", " ");
}

// ================================================================
// STATUS BOX
// ================================================================
function updateStatus(text) { statusBox.innerText = text; }

// ================================================================
// AI DISPLAY HELPERS
// ================================================================
function showAdvice(text, type = "info") {
  if (!adviceBox) return;
  adviceBox.innerText = `AI Advice: ${text}`;
  adviceBox.style.color = type === "warning" ? "#e63946" : type === "success" ? "#2a9d8f" : "#264653";

  if (adaptiveParams.reminderType === "voice" && window.speechSynthesis) {
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = "en-US";
    window.speechSynthesis.speak(utt);
  }
  if (adaptiveParams.reminderType === "popup") alert(`AI Reminder: ${text}`);
}

function updateAIRawResponse(text) {
  if (!aiRawResponseBox) return;
  aiRawResponseBox.innerText = `🔥 AI Raw Response: ${text}`;
}

function updatePrediction(text) {
  if (!predictionBox) return;
  predictionBox.innerText = `📈 AI Prediction: ${text}`;
}

function logAIEvent(type, input, output) {
  if (!aiLogBox) return;
  const time = new Date().toLocaleTimeString();
  const fmtIn  = typeof input  === "object" ? JSON.stringify(input).substring(0, 60)  : input;
  const fmtOut = typeof output === "object" ? JSON.stringify(output).substring(0, 100) : output;
  aiLogBox.innerHTML = `[${time}] ${type}:\nIn: ${fmtIn}...\nOut: ${fmtOut}...\n---\n` + aiLogBox.innerHTML;
  console.log(`[AI ${type}]`, input, "→", output);
}

// ================================================================
// AI PERSISTENCE
// ================================================================
function saveStateHistory() {
  if (stateHistory.length > 100) stateHistory = stateHistory.slice(-100);
  localStorage.setItem("stateHistory",  JSON.stringify(stateHistory));
  localStorage.setItem("adaptiveParams", JSON.stringify(adaptiveParams));
}

// ================================================================
// AI HELPERS
// ================================================================
function getMostFrequentEmotion() {
  const neg = stateHistory.map(s => s.emotion)
    .filter(e => ["angry","sad","fearful","disgusted"].includes(e));
  if (neg.length === 0) return "none";
  const counts = neg.reduce((acc, e) => { acc[e] = (acc[e] || 0) + 1; return acc; }, {});
  return Object.keys(counts).reduce((a, b) => counts[a] > counts[b] ? a : b);
}

function getFallbackAdvice(state) {
  const map = {
    angry_distracted:   "You seem anxious. Take a deep breath first.",
    sad_distracted:     "Don't give up. Rest for 1 minute then continue.",
    sad_focused:        "Try standing up and stretching for 1 minute.",
    neutral_distracted: "Come on! Get back to focus mode quickly!",
    happy_distracted:   "Great mood! Now get back to studying.",
    neutral_focused:    "Stay focused, you're doing great!",
    happy_focused:      "Excellent! Keep up the focused state."
  };
  return map[`${state.emotion}_${state.attention}`] || "Keep it up, stay in the zone!";
}

// ================================================================
// OLLAMA CORE
// ================================================================
async function callOllamaAPI(prompt) {
  const cfg = getOllamaConfig();
  try {
    updateStatus("Requesting AI analysis...");
    const response = await fetch(`${cfg.baseUrl}/api/generate`, {
      method: "POST",
      mode: "cors",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: cfg.model, prompt, stream: false, temperature: 0.7, max_tokens: 200
      })
    });
    if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
    const data = await response.json();
    const fullResponse = data.response?.trim() || "";
    updateStatus("AI analysis complete ✅");
    updateAIRawResponse(fullResponse);
    return fullResponse;
  } catch (error) {
    updateStatus("AI service unavailable ❌");
    updateAIRawResponse(`Request failed: ${error.message}`);
    console.error("Ollama API error:", error);
    return getFallbackAdvice(studentState);
  }
}

// ================================================================
// AI FUNCTION 1: Immediate feedback (on state change)
// ================================================================
async function getImmediateFeedback() {
  const prompt = `
  You are an AI assistant focused on analyzing learning states. Generate a concise, friendly English tip (under 20 words) based on the user's current state.
  Current state:
  - Emotion: ${studentState.emotion}
  - Attention: ${studentState.attention}

  Rules:
  1. Negative emotion (angry/sad/fearful/disgusted) + distracted: prompt to relax, e.g. "You seem anxious. Take a deep breath."
  2. Sad + focused: suggest a micro-break, e.g. "Try standing up and stretching for 1 minute."
  3. Neutral/positive + distracted: encourage return to focus, e.g. "Come on! Get back to focus mode!"
  4. Neutral/positive + focused: encourage or say nothing, e.g. "Great focus! Keep it up!"
  `;
  logAIEvent("Immediate Feedback", { emotion: studentState.emotion, attention: studentState.attention }, "requesting...");
  const advice = await callOllamaAPI(prompt);
  if (advice) {
    const type = studentState.attention === "distracted" &&
      ["angry","sad","fearful","disgusted"].includes(studentState.emotion) ? "warning" : "success";
    showAdvice(advice, type);
    logAIEvent("Immediate Feedback", { emotion: studentState.emotion, attention: studentState.attention }, advice);
  }
}

// ================================================================
// AI FUNCTION 2: Adaptive parameter tuning (every 1 min)
// ================================================================
async function updateAdaptiveParameters() {
  const recent = stateHistory.slice(-50);
  if (recent.length < 5) {
    logAIEvent("Adaptive Tuning", "Not enough history (<5 entries)", "skipped");
    return;
  }
  const prompt = `
  You are an AI optimizer for learning state detection. Update the detection parameters based on the user's history (return JSON only, no other text).
  History (last ${recent.length} entries): ${JSON.stringify(recent)}
  Current parameters: ${JSON.stringify(adaptiveParams)}

  Rules:
  1. If user is frequently distracted (>60% distracted): increase distractedThreshold (+10) or decrease reminderInterval (-5000)
  2. If user is unresponsive to reminders (distracted repeatedly without improvement): change reminderType (text→voice→popup)
  3. If blink rate is abnormal (avg >8 per 10s): raise blinkRateNormalRange upper limit
  4. Return only the updated JSON object, e.g.: {"distractedThreshold": 45, "reminderInterval": 25000, "reminderType": "voice", "blinkRateNormalRange": [2, 9]}
  `;
  logAIEvent("Adaptive Tuning", { recentLen: recent.length, params: adaptiveParams }, "requesting...");
  const newParamsStr = await callOllamaAPI(prompt);
  try {
    const p = JSON.parse(newParamsStr);
    if (p.distractedThreshold)  adaptiveParams.distractedThreshold  = p.distractedThreshold;
    if (p.reminderInterval)     adaptiveParams.reminderInterval      = p.reminderInterval;
    if (p.reminderType)         adaptiveParams.reminderType          = p.reminderType;
    if (p.blinkRateNormalRange) adaptiveParams.blinkRateNormalRange  = p.blinkRateNormalRange;
    saveStateHistory();
    logAIEvent("Adaptive Tuning", { recentLen: recent.length }, p);
    showAdvice("Detection strategy optimized 📝", "info");
  } catch (e) {
    logAIEvent("Adaptive Tuning", "Failed to parse parameters", e.message);
  }
}

// ================================================================
// AI FUNCTION 3: Emotion trend prediction (every 30 sec)
// ================================================================
async function predictEmotionalTrend() {
  const recentHistory = [
    { emotion: studentState.emotion, attention: studentState.attention, timestamp: new Date().toISOString() },
    { emotion: studentState.emotion, attention: studentState.attention, timestamp: new Date(Date.now() - 10000).toISOString() }
  ];
  const prompt = `
  You are an emotion prediction AI. Based on the user's current and recent state, predict their state over the next 5 minutes (concise English, under 30 words).
  Current state: ${JSON.stringify(studentState)}
  Recent records: ${JSON.stringify(recentHistory)}

  Rules:
  1. Predict whether the user will become distracted, fatigued, or emotionally changed
  2. Generate an early-intervention tip
  3. Example: "You may lose focus soon. Try drinking water to stay alert."
  4. Return prediction text only, nothing else.
  `;
  logAIEvent("Emotion Prediction", { currentState: studentState }, "requesting...");
  const prediction = await callOllamaAPI(prompt);
  if (prediction) {
    updatePrediction(prediction);
    showAdvice(`📈 Prediction: ${prediction}`, "info");
    logAIEvent("Emotion Prediction", { currentState: studentState }, prediction);
    if (prediction.toLowerCase().includes("distract") || prediction.toLowerCase().includes("fatigue")) {
      distractedFrames = Math.max(0, distractedFrames - 10);
    }
  } else {
    updatePrediction("Prediction unavailable (using default)");
    showAdvice("📈 Prediction: You're likely to maintain your current state. Keep going!", "info");
  }
}

// ================================================================
// AI FUNCTION 4: Personalized advice (every 2 min)
// ================================================================
async function generatePersonalizedAdvice() {
  const recent = stateHistory.slice(-10);
  if (recent.length < 3) {
    logAIEvent("Personalized Advice", "Not enough history (<3 entries)", "skipped");
    return;
  }
  const hourStats = recent.reduce((acc, item) => {
    const h = new Date(item.timestamp).getHours();
    acc[h] = acc[h] || { distracted: 0, total: 0 };
    acc[h].total++;
    if (item.attention === "distracted") acc[h].distracted++;
    return acc;
  }, {});
  const prompt = `
  You are a personalized learning coach. Generate 3 practical English tips based on the user's state data (each under 30 words, separated by newlines).
  Data summary:
  - Total records: ${recent.length}
  - Distraction by hour: ${JSON.stringify(hourStats)}
  - Most frequent negative emotion: ${getMostFrequentEmotion()}

  Tip directions:
  1. Time management (e.g. "You tend to lose focus at 3pm — schedule a short break then.")
  2. Emotion regulation (e.g. "When feeling negative, try a 5-minute meditation.")
  3. Attention improvement (e.g. "Work in 25-minute blocks with 5-minute breaks.")

  Output format: 3 tips separated by newlines, nothing else.
  `;
  logAIEvent("Personalized Advice", { totalRecords: recent.length, hourStats }, "requesting...");
  const advice = await callOllamaAPI(prompt);
  if (advice && analyticsBox) {
    analyticsBox.innerText = `📋 Personalized Tips:\n${advice}`;
    logAIEvent("Personalized Advice", { totalRecords: recent.length }, advice);
  }
}

// ================================================================
// AI FUNCTION 5: Data analysis report (every 3 min)
// ================================================================
async function analyzeDataOptimization() {
  if (stateHistory.length < 5) {
    logAIEvent("Data Analysis", "Not enough history (<5 entries)", "skipped");
    return;
  }
  const distractedRate = (stateHistory.filter(s => s.attention === "distracted").length /
    stateHistory.length * 100).toFixed(1);
  const blinkRateAvg = blinkTimes.length > 0
    ? (blinkTimes.length / (stateHistory.length / 10)).toFixed(1) : 0;
  const prompt = `
  You are a data analyst. Analyze the user's learning state data and generate an optimization report (concise English, under 100 words).
  Data summary:
  - Total records: ${stateHistory.length}
  - Distraction rate: ${distractedRate}%
  - Average blink rate: ${blinkRateAvg} per 10s
  - Most frequent negative emotion: ${getMostFrequentEmotion()}

  Requirements:
  1. Identify the core problem
  2. Give 1-2 specific optimization suggestions
  3. Keep the language clear and easy to understand
  `;
  logAIEvent("Data Analysis", { distractedRate: distractedRate+"%", blinkRateAvg }, "requesting...");
  const analysis = await callOllamaAPI(prompt);
  if (analysis && analyticsBox) {
    analyticsBox.innerText += `\n\n📊 Data Analysis Report:\n${analysis}`;
    logAIEvent("Data Analysis", { distractedRate, blinkRateAvg }, analysis);
  }
}

// ================================================================
// AI FUNCTION: AI-driven mental status (on every state update)
// ================================================================
async function generateAIDrivenMentalStatus() {
  const currentKey = `${studentState.emotion}_${studentState.attention}`;
  const lastKey    = `${lastAICallState.emotion}_${lastAICallState.attention}`;
  if (currentKey === lastKey) return;
  lastAICallState = { ...studentState };

  const prompt = `
  Based on the emotion and attention level, return the user's mental state (return exactly one of the following keywords, nothing else):
  Options: lost_focus, struggling, fatigued, anxious, frustrated, focused, engaged
  Input:
  - Emotion: ${studentState.emotion}
  - Attention: ${studentState.attention}
  `;
  logAIEvent("Mental State", { emotion: studentState.emotion, attention: studentState.attention }, "requesting...");
  const mentalStatus = await callOllamaAPI(prompt);
  if (mentalStatus) {
    studentState.mentalStatus = mentalStatus.trim();
    logAIEvent("Mental State", {}, studentState.mentalStatus);
  } else {
    // Fallback deterministic map
    if (studentState.attention === "distracted") {
      studentState.mentalStatus = "lost_focus";
    } else {
      const map = {
        angry: "struggling", sad: "fatigued", fearful: "anxious",
        disgusted: "frustrated", neutral: "focused", happy: "engaged", surprised: "engaged"
      };
      studentState.mentalStatus = map[studentState.emotion] || "focused";
    }
  }
}

// ================================================================
// EMOTION DETECTION (face-api.js)
// ================================================================
async function loadEmotionModel() {
  updateStatus("Loading emotion detection model...");
  try {
    await faceapi.nets.tinyFaceDetector.loadFromUri("./models/");
    await faceapi.nets.faceExpressionNet.loadFromUri("./models/");
    updateStatus("Emotion model loaded ✅");
    return true;
  } catch (e) {
    updateStatus("Failed to load emotion model ❌");
    console.error("Model load error:", e);
    return false;
  }
}

function checkModelsLoaded() {
  return faceapi.nets.tinyFaceDetector.isLoaded &&
         faceapi.nets.faceExpressionNet.isLoaded;
}

async function detectEmotion() {
  if (!videoElement || videoElement.paused) return;
  try {
    const options = new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 });
    const detection = await faceapi.detectSingleFace(videoElement, options).withFaceExpressions();
    if (!detection) { studentState.emotion = "neutral"; return; }
    const expr = detection.expressions;
    studentState.emotion = Object.keys(expr).reduce((a, b) => expr[a] > expr[b] ? a : b);
  } catch (e) {
    console.error("Emotion detection error:", e);
  }
}

// ================================================================
// ATTENTION + MENTAL STATE UPDATE
// ================================================================
function distance(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }

function updateMentalStatus() {
  // Push to history
  stateHistory.push({ ...studentState, timestamp: new Date().toISOString(), blinkRate: blinkTimes.length });
  saveStateHistory();

  // Trigger AI feedback on state change
  const currentKey = `${studentState.emotion}_${studentState.attention}`;
  const lastKey    = `${lastState.emotion}_${lastState.attention}`;
  if (currentKey !== lastKey) {
    lastState = { ...studentState };
    clearTimeout(stateStableTimer);
    stateStableTimer = setTimeout(() => { getImmediateFeedback(); }, 1000);
  }

  // AI mental status (async, updates UI when done)
  generateAIDrivenMentalStatus().then(() => updateMentalStateUI());
}

// ================================================================
// LOW-POLY ORANGE MASK (from focus-tool)
// ================================================================
let meshTriangles = null;

function extractTriangles(connections) {
  const adj = new Map();
  for (const [a, b] of connections) {
    if (!adj.has(a)) adj.set(a, new Set());
    if (!adj.has(b)) adj.set(b, new Set());
    adj.get(a).add(b); adj.get(b).add(a);
  }
  const triangles = [], seen = new Set();
  for (const [a, b] of connections) {
    const nA = adj.get(a), nB = adj.get(b);
    if (!nA || !nB) continue;
    for (const c of nA) {
      if (c !== b && nB.has(c)) {
        const tri = [a, b, c].sort((x, y) => x - y);
        const key = (tri[0] << 20) | (tri[1] << 10) | tri[2];
        if (!seen.has(key)) { seen.add(key); triangles.push(tri); }
      }
    }
  }
  return triangles;
}

const MASK_COLORS = {
  darkest:  [140, 65,  10],
  dark:     [193, 89,  15],
  mid:      [227, 119, 31],
  bright:   [241, 163, 59],
  lightest: [246, 194, 96]
};

function getTriangleColor(landmarks, tri) {
  const a = landmarks[tri[0]], b = landmarks[tri[1]], c = landmarks[tri[2]];
  if (!a || !b || !c) return null;
  const abx=b.x-a.x, aby=b.y-a.y, abz=(b.z||0)-(a.z||0);
  const acx=c.x-a.x, acy=c.y-a.y, acz=(c.z||0)-(a.z||0);
  const nx=aby*acz-abz*acy, ny=abz*acx-abx*acz, nz=abx*acy-aby*acx;
  const len=Math.sqrt(nx*nx+ny*ny+nz*nz)||1;
  let dot=((nx/len)*-0.3)+((ny/len)*-0.5)+((nz/len)*0.8);
  dot=Math.abs(dot);
  let r, g, bl;
  if      (dot>0.75) { [r,g,bl]=MASK_COLORS.lightest; }
  else if (dot>0.55) { [r,g,bl]=MASK_COLORS.bright;   }
  else if (dot>0.35) { [r,g,bl]=MASK_COLORS.mid;      }
  else if (dot>0.15) { [r,g,bl]=MASK_COLORS.dark;     }
  else               { [r,g,bl]=MASK_COLORS.darkest;  }
  return `rgb(${r},${g},${bl})`;
}

const LEFT_EYE_SET  = new Set([33,7,163,144,145,153,154,155,133,173,157,158,159,160,161,246,468,469,470,471,472]);
const RIGHT_EYE_SET = new Set([362,382,381,380,374,373,390,249,263,466,388,387,386,385,384,398,473,474,475,476,477]);
function isEyeTriangle(tri) {
  return tri.every(v => LEFT_EYE_SET.has(v)) || tri.every(v => RIGHT_EYE_SET.has(v));
}

// ================================================================
// FACEMESH RESULTS HANDLER
// ================================================================
const faceMesh = new FaceMesh({
  locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`
});
faceMesh.setOptions({
  maxNumFaces: 1, refineLandmarks: true,
  minDetectionConfidence: 0.6, minTrackingConfidence: 0.6
});

faceMesh.onResults((results) => {
  const W = canvasElement.width, H = canvasElement.height;
  canvasCtx.clearRect(0, 0, W, H);
  canvasCtx.save();
  canvasCtx.translate(W, 0);
  canvasCtx.scale(-1, 1);
  canvasCtx.drawImage(results.image, 0, 0, W, H);

  let attentionScore = 0;

  if (results.multiFaceLandmarks.length > 0) {
    const landmarks = results.multiFaceLandmarks[0];
    attentionScore++;

    if (!meshTriangles) meshTriangles = extractTriangles(FACEMESH_TESSELATION);

    // Low-poly orange mask
    for (const tri of meshTriangles) {
      if (isEyeTriangle(tri)) continue;
      const a=landmarks[tri[0]], b=landmarks[tri[1]], c=landmarks[tri[2]];
      if (!a||!b||!c) continue;
      const color = getTriangleColor(landmarks, tri);
      if (!color) continue;
      canvasCtx.beginPath();
      canvasCtx.moveTo(a.x*W, a.y*H);
      canvasCtx.lineTo(b.x*W, b.y*H);
      canvasCtx.lineTo(c.x*W, c.y*H);
      canvasCtx.closePath();
      canvasCtx.fillStyle = color;
      canvasCtx.fill();
      canvasCtx.strokeStyle = "rgba(100,50,0,0.25)";
      canvasCtx.lineWidth = 0.5;
      canvasCtx.stroke();
    }

    // Eye outlines
    canvasCtx.save();
    canvasCtx.strokeStyle = "#f8f0e0";
    canvasCtx.lineWidth = 2;
    canvasCtx.shadowColor = "rgba(255,200,100,0.5)";
    canvasCtx.shadowBlur = 6;
    [
      [33,7,163,144,145,153,154,155,133,173,157,158,159,160,161,246,33],
      [362,382,381,380,374,373,390,249,263,466,388,387,386,385,384,398,362]
    ].forEach(indices => {
      canvasCtx.beginPath();
      indices.forEach((idx, i) => {
        const lm = landmarks[idx];
        if (!lm) return;
        if (i === 0) canvasCtx.moveTo(lm.x*W, lm.y*H);
        else canvasCtx.lineTo(lm.x*W, lm.y*H);
      });
      canvasCtx.stroke();
    });
    canvasCtx.restore();

    // Gaze / attention scoring
    const gaze = (landmarks[33].x + landmarks[263].x) / 2;
    if (gaze > 0.35 && gaze < 0.65) attentionScore++;
    if (Math.abs(gaze - lastGaze) > 0.1) distractedFrames++;
    lastGaze = gaze;

    // Blink (EAR)
    const EAR = (distance(landmarks[159], landmarks[145]) +
                 distance(landmarks[386], landmarks[374])) / 2;
    const now = Date.now();
    if (EAR < 0.018 && now - lastBlinkTime > 300) { blinkTimes.push(now); lastBlinkTime = now; }
    blinkTimes = blinkTimes.filter(t => now - t < 10000);
    if (blinkTimes.length >= adaptiveParams.blinkRateNormalRange[0] &&
        blinkTimes.length <= adaptiveParams.blinkRateNormalRange[1]) attentionScore++;

  } else {
    distractedFrames += 5;
  }

  canvasCtx.restore();

  if (attentionScore < 2) distractedFrames++;
  else distractedFrames = Math.max(0, distractedFrames - 1);

  if (distractedFrames > adaptiveParams.distractedThreshold) {
    studentState.attention = "distracted";
    canvasCtx.save();
    canvasCtx.font = "bold 20px 'PingFang SC', sans-serif";
    canvasCtx.shadowColor = "#ff4444"; canvasCtx.shadowBlur = 16;
    canvasCtx.fillStyle = "#ff6b6b";
    canvasCtx.fillText("⚠ Attention drifting!", 24, 36);
    canvasCtx.restore();
  } else {
    studentState.attention = "focused";
  }

  updateMentalStatus();
  statusBox.innerText = `Emotion: ${studentState.emotion} | Attention: ${studentState.attention}`;
  checkAndRemind();
});

// ================================================================
// CAMERA
// ================================================================
const camera = new Camera(videoElement, {
  onFrame: async () => { await faceMesh.send({ image: videoElement }); },
  width: 480, height: 360
});

// ================================================================
// AUDIO
// ================================================================
function playBeep() {
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  const ctx = new AC();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = "sine"; osc.frequency.value = 880;
  gain.gain.value = 0.1;
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(); osc.stop(ctx.currentTime + 0.25);
}

// ================================================================
// POMODORO TIMER
// ================================================================
function formatTime(seconds) {
  return `${String(Math.floor(seconds/60)).padStart(2,"0")}:${String(seconds%60).padStart(2,"0")}`;
}
function formatMinutes(seconds) {
  const m = seconds / 60;
  return Number.isInteger(m) ? `${m}` : `${m.toFixed(1)}`;
}
function getModeDuration(m) { return m === "work" ? workSeconds : breakSeconds; }
function computeDisplaySeconds() {
  if (!isRunning || !endTimestamp) return remainingSeconds;
  return Math.max(0, Math.ceil((endTimestamp - Date.now()) / 1000));
}

function playBeepAndToast(finishedMode) {
  playBeep();
  showToast(finishedMode === "work" ? "🍅 Focus session complete! Take a break." : "☕ Break over! Ready to focus again.", "info", 5000);
}

function handleTimerComplete() {
  const finished = mode;
  mode = finished === "work" ? "break" : "work";
  remainingSeconds = getModeDuration(mode);
  isRunning = false; endTimestamp = null;
  playBeepAndToast(finished);
  saveState(); updateTimerUI();
}

function updateTimerUI() {
  const displaySecs = computeDisplaySeconds();
  timerEl.textContent = formatTime(displaySecs);
  const modeText = mode === "work" ? "Focus" : "Break";
  statusTextEl.textContent = `Current mode: ${modeText}`;
  workBtn.classList.toggle("active", mode === "work");
  breakBtn.classList.toggle("active", mode === "break");
  workBtn.textContent  = `Focus ${formatMinutes(workSeconds)} min`;
  breakBtn.textContent = `Break ${formatMinutes(breakSeconds)} min`;
  const idleSecs = Math.floor((Date.now() - lastActivity) / 1000);
  idleTextEl.textContent = idleSecs < 1 ? "Active" : `Idle for ${idleSecs}s`;
  startPauseBtn.textContent = isRunning ? "Pause" : "Start";
  document.title = `${timerEl.textContent} - ${modeText} - Focus Tool`;
  if (isRunning && displaySecs <= 0) handleTimerComplete();
}

function toggleStartPause() {
  if (isRunning) {
    remainingSeconds = computeDisplaySeconds();
    isRunning = false; endTimestamp = null;
  } else {
    if (remainingSeconds <= 0) remainingSeconds = getModeDuration(mode);
    endTimestamp = Date.now() + remainingSeconds * 1000;
    isRunning = true;
  }
  saveState(); updateTimerUI();
}

function setMode(nextMode) {
  mode = nextMode; remainingSeconds = getModeDuration(nextMode);
  isRunning = false; endTimestamp = null;
  saveState(); updateTimerUI();
}

function resetCurrentMode() {
  remainingSeconds = getModeDuration(mode);
  isRunning = false; endTimestamp = null;
  saveState(); updateTimerUI();
}

function setDurations(newWorkMinutes, newBreakMinutes) {
  workSeconds  = Math.max(1, Math.floor(newWorkMinutes  * 60));
  breakSeconds = Math.max(1, Math.floor(newBreakMinutes * 60));
  if (!isRunning) { remainingSeconds = getModeDuration(mode); endTimestamp = null; }
  saveState(); updateTimerUI();
}

// ================================================================
// PERSISTENCE (localStorage)
// ================================================================
const STORAGE_KEY = "focusToolState";

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(
      { mode, remainingSeconds, isRunning, endTimestamp, workSeconds, breakSeconds }
    ));
  } catch (_) {}
}

function loadState() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!raw) return;
    mode             = raw.mode === "break" ? "break" : "work";
    workSeconds      = Number.isFinite(raw.workSeconds)  ? Math.max(1, Math.floor(raw.workSeconds))  : DEFAULT_WORK_SECONDS;
    breakSeconds     = Number.isFinite(raw.breakSeconds) ? Math.max(1, Math.floor(raw.breakSeconds)) : DEFAULT_BREAK_SECONDS;
    remainingSeconds = Number.isFinite(raw.remainingSeconds) ? Math.max(0, Math.floor(raw.remainingSeconds)) : getModeDuration(mode);
    isRunning        = Boolean(raw.isRunning);
    endTimestamp     = (isRunning && Number.isFinite(raw.endTimestamp)) ? raw.endTimestamp : null;
    if (isRunning && endTimestamp) {
      const msLeft = endTimestamp - Date.now();
      if (msLeft <= 0) { handleTimerComplete(); return; }
      remainingSeconds = Math.ceil(msLeft / 1000);
    }
    if (!isRunning) endTimestamp = null;
    workMinutesInput.value  = (workSeconds / 60).toString();
    breakMinutesInput.value = (breakSeconds / 60).toString();
  } catch (_) {}
}

// ================================================================
// IDLE DETECTION
// ================================================================
function markActivity() { lastActivity = Date.now(); hasIdleNotified = false; }

function refreshIdleState() {
  const idleSecs = Math.floor((Date.now() - lastActivity) / 1000);
  if (idleSecs >= 60 && !hasIdleNotified) {
    hasIdleNotified = true;
    playBeep();
    showToast("⏰ You've been idle for 1 minute. Stay focused or take a rest.", "warning", 5000);
  }
}

// ================================================================
// SCHEDULED AI TASKS
// ================================================================
function setupScheduledTasks() {
  setInterval(updateAdaptiveParameters,  1 * 60 * 1000);
  setInterval(predictEmotionalTrend,    30 * 1000);
  setInterval(generatePersonalizedAdvice, 2 * 60 * 1000);
  setInterval(analyzeDataOptimization,   3 * 60 * 1000);
  // Run once shortly after start
  setTimeout(() => {
    predictEmotionalTrend();
    generatePersonalizedAdvice();
    analyzeDataOptimization();
  }, 8000);
}

// ================================================================
// EVENT LISTENERS
// ================================================================
startPauseBtn.addEventListener("click", toggleStartPause);
resetBtn.addEventListener("click", resetCurrentMode);
workBtn.addEventListener("click",  () => setMode("work"));
breakBtn.addEventListener("click", () => setMode("break"));

workMinutesInput.addEventListener("change", () => {
  const v = parseFloat(workMinutesInput.value);
  if (Number.isFinite(v) && v > 0) setDurations(v, breakSeconds / 60);
  else workMinutesInput.value = (workSeconds / 60).toString();
});
breakMinutesInput.addEventListener("change", () => {
  const v = parseFloat(breakMinutesInput.value);
  if (Number.isFinite(v) && v > 0) setDurations(workSeconds / 60, v);
  else breakMinutesInput.value = (breakSeconds / 60).toString();
});

["mousemove","mousedown","keydown","touchstart","wheel"].forEach(ev => {
  window.addEventListener(ev, markActivity, { passive: true });
});

window.addEventListener("beforeunload", saveStateHistory);

// ================================================================
// INIT
// ================================================================
async function init() {
  try {
    loadState();
    updateTimerUI();
    setInterval(() => { updateTimerUI(); refreshIdleState(); }, 500);

    updateStatus("Initializing system...");
    await loadEmotionModel();
    if (!checkModelsLoaded()) { updateStatus("Error: models failed to load"); return; }

    updateStatus("Requesting camera permission...");
    await camera.start();
    updateStatus("System ready ✅ | Emotion: neutral | Attention: focused");

    setInterval(detectEmotion, 2000);
    setupScheduledTasks();
  } catch (e) {
    updateStatus("系统启动失败 ❌：" + e.message);
    console.error("Init error:", e);
  }
}

init();
